Steps in ServerSide
// Steps are valid as of now, 2022 June 6th.
// 0) From Google spreadsheet, Extensions> App Script
// 1) Write your code
// 2) Save and give a meaningful name
// 3) Run and make sure "doGet" is selected
//    You can set a method from Run menu
// 4) When you run for the first time, it will ask 
//    for the permission. You must allow it.
//    Make sure everything is working as it should.
// 5) From Top right click Deploy.
//    Select a new version everytime it's published
//    Type descriptionsnext to the version
//    Execute as: "Me (your email address)"
//    MUST: Select "Anyone" on "Who has access to this script"
//    For the first time it will give you some prompt(s), accept it.
//    You will need the given information (url) later. This doesn't change, ever!

// Saving the published URL helps for later.
// https://script.google.com/macros/s/---Your-Script-ID--Goes-Here---/exec
// https://script.google.com/macros/s/---Your-Script-ID--Goes-Here---/exec?tag=test&value=-1


================================================================
1. Create a new Google Spreadsheet in your account.
2. Goto Extensions> App Script and copy all the code from *GoogleScript.gs* into the editor.
3. You can goto the menu item "ESP8266 Logging -> Clear" to clear all the row contents from the sheet.
4. Get your *spreadsheet-id*. If you look at the URL in the browser tab where the spreadsheet is open, it'll be of the form: 
`https://docs.google.com/spreadsheets/d/<random-string>/edit#gid=0`. The *\<random string>* is your *spreadsheet-id*. Put this value in *GoogleScript.gs* in the relevant line.
5. Publish your script by deploying it as a web app. The permissions should be set to "Execute the app as: Me (your email)" and "who has access to the app: Anyone". Once you publish your script, the script editor popup will say: "This project is now deployed as a web app.". It'll also display the URL for the webapp. Grab the string of random characters between "/macros/s/" and /"exec".

Example: If your URL looks like this: `https://script.google.com/macros/s/XXXYYY/exec`, then "XXXYYY" is your **GScriptId**. Put this value in GoogleDocs.ino for it to hit your script instead of mine.

**Important Note:** You need to re-publish your web-app (with a new version number) **every time** any change any made to your script. Google Apps script serves requests only with a published version of your script, not necessarily the *latest* one. This is an unfortunate Google Apps Script limitation. However, your *GScriptId* will remain the same.

6. Once these steps are completed, re-flash your ESP82666 with the new spreadsheet-id code. It should then read and write to your copy of the spreadsheet.

---
Note: HTTPSRedirect is free for personal, non-commercial use only. In case of use for profit or more than 10 devices per person, please contact the author for purchasing a licence.

I hope you enjoy using this library. Please try it out for yourself. Your comments and suggestions are most welcome.
